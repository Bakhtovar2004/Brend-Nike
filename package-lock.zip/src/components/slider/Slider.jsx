import React from 'react'
import './Slider.css'
export default function Slider() {
  return (
    <div className='slider'>
      <img src="./slider.webp" alt="" />
      <div className="absolute">
        <h1>SAVE UP TO 50%</h1>
        <h3>Save big on limited-time markdowns-no code required.Exclusions apply</h3>
        <button className='button'>Shop</button>
      </div>

    </div>
  )
}
