import React from 'react'

export default function Product({ nike }) {
    return (
        <div>
            <div className="card">
                <img src={nike.src} alt="" />
                <p className='brown'>{nike.just}</p>
                <p>{nike.brend}</p>
                <p>{nike.forMen}</p>
                <p>{nike.color}</p>
                <p>{nike.price} $</p>
            </div>
        </div>
    )
}
