import React from 'react'
import Product from './Product'
import './Products.css'
export default function Products() {

  const nikes = [
    {
      id: 1,
      src: "./Pulse.webp",
      just: "Just In",
      brend: "Nike Air Max Pulse",
      forMen: "Men`s shoes",
      color: "1 color",
      price:150,
    },
    {
      id: 2,
      src: "./91.webp",
      just: "Top",
      brend: "Nike Air Max 90",
      forMen: "Men`s shoes",
      color: "2 color",
      price: 172.54,
    },
    {
      id: 3,
      src: "./Plus.webp",
      just: "New",
      brend: "Nike Air Max SC",
      forMen: "Men`s shoes",
      color: "9 color",
      price: 83.5,
    },
    {
      id: 4,
      src: "./29.webp",
      just: "Best Seller",
      brend: "Nike Air Max 270",
      forMen: "Men`s shoes",
      color: "8 color",
      price: 160,
    },
    {
      id: 5,
      src: "./SYSTM.webp",
      just: "New",
      brend: "Nike Air Max SYSTM",
      forMen: "Men`s shoes",
      color: "4 color",
      price: 100,
    },
    {
      id: 6,
      src: "./Seller.webp",
      just: "Top",
      brend: "Nike Air Max Seller",
      forMen: "Men`s shoes",
      color: "2 color",
      price: 164,
    },
    {
      id: 7,
      src: "./Penny.webp",
      just: "Best Seller",
      brend: "Nike Air Max Penny",
      forMen: "Men`s shoes",
      color: "7 color",
      price: 135,
    },
    {
      id: 8,
      src: "./gtx.webp",
      just: "Just In",
      brend: "Nike Air Max GTX",
      forMen: "Men`s shoes",
      color: "5 color",
      price: 186,
    },
    {
      id: 9,
      src: "./se.webp",
      just: "New",
      brend: "Nike Air Max SC",
      forMen: "Men`s shoes",
      color: "8 color",
      price: 98,
    },
    {
      id: 10,
      src: "./max.webp",
      just: "Just In",
      brend: "Nike Air Max 91",
      forMen: "Men`s shoes",
      color: "3 color",
      price: 170,
    },
    {
      id: 11,
      src: "./se1.webp",
      just: "Top Year",
      brend: "Nike Air Max SE",
      forMen: "Men`s shoes",
      color: "5 color",
      price: 125.8,
    },
    {
      id: 12,
      src: "./2090.webp",
      just: "Best Seller",
      brend: "Nike Air Max 2090",
      forMen: "Men`s shoes",
      color: "3 color",
      price: 110,
    },

  ];

  return (
    <div className='products'>
      {nikes.map((nike) => (
      <Product nike={nike} />
      ))}
    </div>
  )
}
