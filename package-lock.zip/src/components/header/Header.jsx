import React from 'react'
import './Header.css'

export default function Header() {
  return (
    <div className='header'>
      <div className="logo">
        <img src="https://logowik.com/content/uploads/images/697_nike.jpg" alt="" />
      </div>
      <div className="menu">
        <a href="home">Home</a>
        <a href="New">New</a>
        <a href="Men">Men</a>
        <a href="Women">Women</a>
        <a href="Kids">Kids</a>
        <a href="Sale">Sale</a>
        <a href="Contact">Contact</a>
        <a href="About">About</a>
        <a href="help">Help</a>
      </div>
      <div className="search">
        <form>
          <input className='search' type='text' placeholder="Search here!" />
          <input className='submit' type="submit" value="Search" />
        </form>
      </div>
      <div className="main">

        <div className="favorites">
          <img src="./звезда.png " title='Изобранные' alt="" />
          <img src="./иконка.png" title='Список заказов' alt="" />
        </div>
        <div className="sing-up">
          <a href="sing-up">Sing up</a>
        </div>
      </div>

    </div>
  )
}
