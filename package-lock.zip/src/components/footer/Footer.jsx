import React from 'react'
import './Footer.css'

export default function footer() {
  return (
    <div className='footer'>
      <div className="contact">
        <div className="gift">
          <b><a href="GIFT CARDS">GIFT CARDS</a></b>
          <b><a href="PROMOTIONS">PROMOTIONS</a></b>
          <b><a href="FIND A STORE">FIND A STORE</a></b>
          <b><a href="SING UP FOR EMAIL">SING UP FOR EMAIL</a></b>
          <b><a href="BECOME A MEMBER">BECOME A MEMBER</a></b>
          <b><a href="NIKE JOURNAL">NIKE JOURNAL</a></b>
          <b><a href="SEND US FEEDBACK">SEND US FEEDBACK</a></b>
        </div>
        <div className="help">
          <b><a href="GET HELP">GET HELP</a></b>
          <a href="O">Order Status</a>
          <a href="Sh">Shipping and Delivery</a>
          <a href="r">Returns</a>
          <a href="P">Payment Options</a>
          <a href="g">Gift Card Balance</a>
          <a href="c">Contact Us</a>
        </div>
        <div className="nice">
          <b><a href="A">ABOUT NIKE</a></b>
          <a href="n">News</a>
          <a href="Careers">Careers</a>
          <a href="i">Investors</a>
          <a href="Purpose">Purpose</a>
          <a href="s">Sustainability</a>
        </div>
      </div>
      <div className="usa"><b>United States </b> <p>@ 2023 Nike,Inc All Rights Reserved</p></div>
    </div>
  )
}
